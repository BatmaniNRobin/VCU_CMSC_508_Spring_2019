-- this one should have been before insert or update of job_id, salary on employees because this trigger is recursive in its current state

-- handle new employee with new min
-- handle new employee with new max
-- handle job_id change of current employee

create or replace trigger jobs_min_max_salary
before insert or update of job_id on jobs
for each row
declare
    var1 int;
begin
    if inserting or (updating and :old.job_id != :new.job_id)-- and :new.salary < min_salary)
    then
        update jobs
        set min_salary = (select min(salary) from employees where job_id = :new.job_id)
        where job_id = :new.job_id;
    end if;
    if inserting or (updating and :old.job_id != :new.job_id)-- and :new.salary > min_salary)
    then
        update jobs
        set max_salary = (select max(salary) from employees where job_id = :new.job_id)
        where job_id = :new.job_id;
    end if;
    if inserting or updating-- and :new.salary < min_salary)
    then
        update jobs
        set min_salary = (select min(salary) from employees where job_id = :new.job_id)
        where job_id = :new.job_id;
    end if;
    if inserting or updating-- and :new.salary > min_salary)
    then
        update jobs
        set max_salary = (select max(salary) from employees where job_id = :new.job_id)
        where job_id = :new.job_id;
    end if;
end;
/

update employees
set salary = 900000
where first_name like 'Mohammad';

select * from jobs;


create or replace trigger jobs_min_max_salary
before insert or update of job_id on jobs
for each row
declare
    var1 int;
begin
    if inserting or (updating and :old.job_id != :new.job_id and :new.salary < min_salary)
    then
        update min_salary
        set min_salary = :new.salary
        where job_id = :new.job_id;
    end if;
    if inserting or (updating and :old.job_id != :new.job_id and :new.salary > min_salary)
    then
        update max_salary
        set max_salary = :new.salary
        where job_id = :new.job_id;
    end if;
end;
/

/*
drop trigger jobs_min_max_salary;

create or replace trigger jobs_min_max_salary
before insert or update of job_id, salary on employees
for each row
begin
    if inserting or (updating and :old.job_id != :new.job_id)-- and :new.salary < (select(min(salary))))
    then
        if (:new.salary < (select min(salary) from employees where job_id = :new.job_id))
        then
            update min_salary
            set min_salary = :new.salary
            where job_id = :new.job_id;
        else if(:new.salary > (select min(salary) from employees where job_id = :new.job_id))
        then
            update max_salary
            set max_salary = :new.salary
            where job_id = :new.job_id;
        end if;
        end if;
    end if;
end;
/
*/