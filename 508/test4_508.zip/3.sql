-- his answer should have had empID out employees.employee_id%TYPE as a parameter in order to have returned it as out put parameter

create sequence AI
    start with 1000
    increment by 1
    nocycle;


create or replace procedure add_employ (p_first_name in employees.first_name%TYPE,
                                        p_last_name in employees.last_name%TYPE,
                                        p_email in employees.email%TYPE,
                                        p_job_id in employees.job_id%TYPE)
as
    empID int;
begin
    insert into employees(employee_id, first_name, last_name, email, hire_date, job_id) values (AI.nextval, p_first_name, p_last_name, p_email, sysdate, p_job_id);
    select employee_id into empID
    from employees
    where first_name = p_first_name
        and last_name = p_last_name
        and email = p_email
        and job_id = p_job_id;
--        return empID;
end;
/

exec add_employ('Mohammad', 'Malik', 'malikmui@vcu.edu', 'AD_PRES');

select * from employees where first_name like 'Mohammad';

delete from employees where first_name like 'Mohammad';