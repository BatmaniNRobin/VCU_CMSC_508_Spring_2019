-- the answer to this one did not need the and statement in the where clause, it returns something quite different

create or replace function difference (p_employee_id in employees.employee_id%TYPE)
    return int
as
    salary_diff int;
begin
    select (max(e.salary)-min(e.salary)) into salary_diff
    from employees e, employees m
    where p_employee_id = m.employee_id
    and e.manager_id = m.employee_id;
    return salary_diff;
end;
/

drop view results;
create view results
as
    select first_name||' '||last_name as "Manager's Full Name", difference(employee_id) as difference
    from employees;
    

select * from results;

select distinct manager_id from employees;