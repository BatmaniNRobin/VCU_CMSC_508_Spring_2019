-- this answer should not have returned 0 for larger outside of dept where dept is null

create or replace function larger(p_employee_id in employees.employee_id%TYPE)
    return int
as
    outer_count int;
begin
    select count(employee_id) into outer_count
    from employees
    where salary > (select salary
                    from employees
                    where employee_id = p_employee_id)
    and department_id not in (select department_id
                                from employees
                                where employee_id = p_employee_id);
    return outer_count;
end;
/

create or replace function lesser(p_employee_id in employees.employee_id%TYPE)
    return int
as
    inner_count int;
begin
    select count(*) into inner_count
    from employees
    where salary < (select salary
                    from employees
                    where employee_id = p_employee_id)
    and department_id = (select department_id
                        from employees
                        where employee_id = p_employee_id);
    return inner_count;
end;
/

select e.first_name ||' '||e.last_name as Fullname, d.department_name as department_name, lesser(employee_id)as lesser, larger(employee_id) as larger
from employees e join departments d
    on e.department_id = d.department_id
union
select e.first_name ||' '||e.last_name as Fullname, 'No department assigned' as department_name, nvl(lesser(employee_id),0) as lesser, larger(employee_id) as larger
from employees e
where department_id is null;