--not department managers salary though smh
select d.department_name, m.first_name||' '||m.last_name Name, AVG(e.salary), count(*)
from employees e left join employees m 
    on e.manager_id = m.employee_id
left join departments d
    on e.department_id = d.department_id
where m.salary > 10000
group by d.department_name, m.first_name||' '||m.last_name;


-- who are these people
select department_name, m.first_name||' '||m.last_name Name, AVG(e.salary), count(*)
from departments d join employees e
    using (department_id)
join employees m
    using (department_id)
where m.salary > 10000
group by d.department_name, m.first_name||' '||m.last_name;

-- some things to help

select distinct manager_id 
from employees;

select department_name
from departments;

select *
from employees join departments
    using (department_id)
where department_name = 'Marketing';

select *
from employees join departments
    using (department_id)
where department_name = 'Sales';