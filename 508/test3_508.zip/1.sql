create table hr_projects(
    project_number number(6,0),
    project_name varchar(30) NOT NULL,
    project_manager number(6,0),
    project_department number(4,0),
    project_budget number(10,2),
    primary key (project_number),
    foreign key (project_manager) references employees,
    foreign key (project_department) references departments);