insert into employees(employee_id, last_name, email, hire_date, job_id) values (1234, 'Malik', 'malikmui@vcu.edu', SYSDATE, 'IT_PROG');

update employees
set salary = 80000
where employee_id = 1234;

delete
from employees
where employee_id = 1234;