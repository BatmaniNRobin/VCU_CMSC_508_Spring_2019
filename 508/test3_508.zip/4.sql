select e.first_name||' '||e.last_name as "Full Name", d.department_name, l.city, j.job_title
from employees e
join departments d
    on e.department_id = d.department_id
join locations l
    on d.location_id = l.location_id
join jobs j
    on e.job_id = j.job_id
where j.job_title LIKE '%Manager%'
and j.job_title NOT LIKE '%Sales%';